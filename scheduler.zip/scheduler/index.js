const express = require('express')
const app = express()
const server = require('http').Server(app)
const nodemailer = require('nodemailer')
const schedule = require('node-schedule')

app.use(express.static('public'))
app.use(express.urlencoded())
app.use(express.json())

app.get('/form', (req, res) => {
    res.sendFile(__dirname + '/public/form.html')
})

app.post('/submit', (req, res) => {
    const email = req.body.email
    const fullname = req.body.fullname
    const date = new Date(req.body.apptime)
    const task = req.body.schedule

    const transporter = nodemailer.createTransport({
        service : "hotmail",
        auth : {
            user : "samwondim@outlook.com",
            pass : "klunu4701"
        }
    })

    const options = {
        from : "samwondim@outlook.com",
        to : `${email}`,
        subject : "Appointment Reminder",
        text : `Dear ${fullname} you have a registered ${task} appointment at ${date.toString()}`
    }   

    schedule.scheduleJob(date, () => {
        transporter.sendMail(options, (err, info) => {
            if(err) {
                console.log(err)
                return
            }
            console.log("sent: " + info.response)
        })
    })   

    console.log(email, fullname, date.getDate().toString())
    res.send('Your appointment has been scheduled. You will get an email reminder from us.')

})

app.listen(3000, () => {
    console.log('listening on port 3000')
})